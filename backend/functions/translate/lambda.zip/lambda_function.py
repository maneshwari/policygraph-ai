import json
import os
import urllib.request

GEMINI_API_KEY = os.environ.get("GEMINI_API_KEY", "") 
GEMINI_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent"
STYLE_PROMPTS = {
    "simple":      "Use simple, everyday language that a rural citizen with basic literacy can understand.",
    "formal":      "Use formal government register, as would appear in official documents.",
    "explanatory": "Translate and add a brief explanation in parentheses to help rural citizens understand what it means practically for them.",
}

def lambda_handler(event, context):
    headers = {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "Content-Type",
        "Access-Control-Allow-Methods": "POST,OPTIONS"
    }
    if event.get("httpMethod") == "OPTIONS":
        return {"statusCode": 200, "headers": headers, "body": ""}

    try:
        body = json.loads(event.get("body", "{}"))
        clauses  = body.get("clauses", [])
        language = body.get("language", "Hindi")
        style    = body.get("style", "simple")

        if not clauses:
            return {"statusCode": 400, "headers": headers,
                    "body": json.dumps({"error": "clauses array required"})}

        if not GEMINI_API_KEY:
            return {"statusCode": 500, "headers": headers,
                    "body": json.dumps({"error": "GEMINI_API_KEY not configured"})}

        style_instruction = STYLE_PROMPTS.get(style, STYLE_PROMPTS["simple"])
        clause_lines = "\n".join(
            f'[{c.get("clause_id", f"c{i+1:03d}")}] {c.get("text", json.dumps(c))}'
            for i, c in enumerate(clauses)
        )

        prompt = f"""Translate the following government policy clauses into {language}.
{style_instruction}

Return ONLY a JSON array in this exact format, no markdown, no preamble, no extra text:
[{{"clause_id": "...", "translation": "..."}}]

Clauses:
{clause_lines}"""

        payload = json.dumps({
            "contents": [{"parts": [{"text": prompt}]}],
            "generationConfig": {"temperature": 0.1, "maxOutputTokens": 3000}
        }).encode("utf-8")

        req = urllib.request.Request(
            f"{GEMINI_URL}?key={GEMINI_API_KEY}",
            data=payload,
            headers={"Content-Type": "application/json"},
            method="POST"
        )

        with urllib.request.urlopen(req, timeout=25) as resp:
            result = json.loads(resp.read())

        raw_output = result["candidates"][0]["content"]["parts"][0]["text"]

        cleaned = raw_output.strip()
        if cleaned.startswith("```"):
            cleaned = cleaned.split("```", 2)[-1]
            if cleaned.startswith("json"):
                cleaned = cleaned[4:]
        cleaned = cleaned.strip().rstrip("```").strip()

        translations = json.loads(cleaned)

        return {
            "statusCode": 200,
            "headers": headers,
            "body": json.dumps({
                "language": language,
                "style": style,
                "translations": translations
            })
        }

    except json.JSONDecodeError as e:
        return {"statusCode": 500, "headers": headers,
                "body": json.dumps({"error": f"Model returned invalid JSON: {str(e)}"})}
    except Exception as e:
        return {"statusCode": 500, "headers": headers,
                "body": json.dumps({"error": str(e)})}