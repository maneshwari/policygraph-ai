import json
import boto3
import os
import time
from datetime import datetime, timezone
from decimal import Decimal

s3 = boto3.client("s3")
textract = boto3.client("textract")
bedrock = boto3.client("bedrock-runtime", region_name="ap-south-1")
dynamodb = boto3.resource("dynamodb")

TABLE_NAME = os.environ["JOBS_TABLE"]
BUCKET_NAME = os.environ["BUCKET_NAME"]
BEDROCK_MODEL = "anthropic.claude-3-haiku-20240307-v1:0"


# ── DynamoDB helpers ────────────────────────────────────────────────────────

def update_job(table, job_id, updates):
    now = datetime.now(timezone.utc).isoformat()
    updates["updated_at"] = now
    expr = "SET " + ", ".join(f"#{k} = :{k}" for k in updates)
    names = {f"#{k}": k for k in updates}
    values = {f":{k}": float_to_decimal(v) for k, v in updates.items()}
    table.update_item(
        Key={"job_id": job_id},
        UpdateExpression=expr,
        ExpressionAttributeNames=names,
        ExpressionAttributeValues=values,
    )


def float_to_decimal(obj):
    if isinstance(obj, float):
        return Decimal(str(obj))
    if isinstance(obj, dict):
        return {k: float_to_decimal(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [float_to_decimal(i) for i in obj]
    return obj


# ── Textract ────────────────────────────────────────────────────────────────

def extract_text_sync(s3_key):
    """Sync Textract — fast, works for <= 5 pages."""
    response = textract.detect_document_text(
        Document={"S3Object": {"Bucket": BUCKET_NAME, "Name": s3_key}}
    )
    lines = [b["Text"] for b in response["Blocks"] if b["BlockType"] == "LINE"]
    return "\n".join(lines)


def extract_text_async(s3_key):
    """Async Textract — handles up to 50 pages."""
    response = textract.start_document_text_detection(
        DocumentLocation={"S3Object": {"Bucket": BUCKET_NAME, "Name": s3_key}}
    )
    job_id = response["JobId"]

    for _ in range(60):  # poll up to 5 minutes
        result = textract.get_document_text_detection(JobId=job_id)
        status = result["JobStatus"]
        if status == "SUCCEEDED":
            break
        if status == "FAILED":
            raise Exception(f"Textract async failed for {s3_key}: {result.get('StatusMessage')}")
        time.sleep(5)
    else:
        raise Exception(f"Textract timed out after 5 minutes for {s3_key}")

    lines = []
    next_token = None
    while True:
        kwargs = {"JobId": job_id}
        if next_token:
            kwargs["NextToken"] = next_token
        result = textract.get_document_text_detection(**kwargs)
        for block in result.get("Blocks", []):
            if block["BlockType"] == "LINE":
                lines.append(block["Text"])
        next_token = result.get("NextToken")
        if not next_token:
            break

    return "\n".join(lines)


def extract_text(s3_key):
    """Try sync first (fast), fall back to async for large docs."""
    try:
        return extract_text_sync(s3_key)
    except textract.exceptions.InvalidParameterException:
        # Multi-page PDF — use async
        return extract_text_async(s3_key)
    except Exception as e:
        err = str(e)
        if "page" in err.lower() or "multipage" in err.lower() or "unsupported" in err.lower():
            return extract_text_async(s3_key)
        raise


# ── Bedrock helpers ─────────────────────────────────────────────────────────

def invoke_bedrock(prompt, max_tokens=2000):
    body = json.dumps({
        "anthropic_version": "bedrock-2023-05-31",
        "max_tokens": max_tokens,
        "messages": [{"role": "user", "content": prompt}],
    })
    response = bedrock.invoke_model(
        modelId=BEDROCK_MODEL,
        body=body,
        contentType="application/json",
        accept="application/json",
    )
    raw = json.loads(response["body"].read())["content"][0]["text"]
    # Strip markdown fences if present
    raw = raw.strip()
    if raw.startswith("```"):
        raw = raw.split("\n", 1)[-1]
        raw = raw.rsplit("```", 1)[0]
    return raw.strip()


def analyze_policy(text):
    prompt = f"""You are an expert insurance policy analyst for Indian government schemes.
Analyze the following policy document and return a JSON object with these exact keys:
- clauses_extracted: integer count of clauses found
- complexity_score: integer 1-10
- complexity_category: "Low" | "Medium" | "High"
- summary: 2-3 sentence plain-English summary
- policy_type: type of policy (health/life/auto/property/government_scheme/etc.)
- clauses: array of objects with {{id, title, text, category}}
- ambiguous_clauses: array of clause ids that are vague or unclear
- key_entities: array of {{name, type, description}}
- graph: {{nodes: [{{id, label, type}}], edges: [{{source, target, label}}]}}
- eligibility_criteria: array of eligibility conditions as plain strings

Return ONLY valid JSON. No markdown, no explanation.

Policy text (first 6000 words):
{" ".join(text.split()[:6000])}"""

    raw = invoke_bedrock(prompt, max_tokens=3000)
    return json.loads(raw)


def check_eligibility(text, clauses):
    clauses_text = "\n".join(f"- {c}" for c in clauses[:20])
    prompt = f"""You are an insurance eligibility expert for Indian government schemes.
From the policy clauses below, extract eligibility information and return JSON with:
- eligible_groups: array of who is eligible (age ranges, income, employment, residency, etc.)
- ineligible_groups: array of who is explicitly excluded
- waiting_periods: array of waiting periods before coverage
- pre_existing_conditions: string describing how pre-existing conditions are handled
- enrollment_requirements: array of requirements to enroll
- dependents: string describing dependent coverage rules

Return ONLY valid JSON. No markdown.

Policy clauses:
{clauses_text}"""

    raw = invoke_bedrock(prompt, max_tokens=1500)
    return json.loads(raw)


def find_conflicts(text, clauses):
    clauses_text = "\n".join(f"- {c}" for c in clauses[:20])
    prompt = f"""You are a legal expert reviewing Indian insurance policies for conflicts and issues.
Analyze these policy clauses and return JSON with:
- conflicts: array of {{clause_a, clause_b, description}} for contradictory clauses
- ambiguous_clauses: array of {{clause, issue}} for vague terms
- concerning_clauses: array of {{clause, reason}} for unusually restrictive clauses
- missing_standard_coverage: array of standard coverages that seem absent
- recommendations: array of questions citizens should ask the insurer

Return ONLY valid JSON. No markdown.

Policy clauses:
{clauses_text}"""

    raw = invoke_bedrock(prompt, max_tokens=1500)
    return json.loads(raw)


# ── Main handler ────────────────────────────────────────────────────────────

def lambda_handler(event, context):
    job_id = event.get("job_id")
    s3_key = event.get("s3_key")

    if not job_id or not s3_key:
        print("ERROR: Missing job_id or s3_key in event")
        return

    table = dynamodb.Table(TABLE_NAME)

    try:
        # ── Stage 1: PROCESSING / Textract ──────────────────────────────────
        update_job(table, job_id, {"status": "PROCESSING", "stage": "textract"})
        print(f"[{job_id}] Starting Textract for {s3_key}")

        text = extract_text(s3_key)
        word_count = len(text.split())
        char_count = len(text)
        print(f"[{job_id}] Textract done: {word_count} words, {char_count} chars")

        update_job(table, job_id, {
            "stage": "bedrock",
            "text_blocks": word_count,
            "char_count": char_count,
        })

        # ── Stage 2: Bedrock analysis ────────────────────────────────────────
        print(f"[{job_id}] Running Bedrock analysis")
        analysis = analyze_policy(text)

        # Extract plain clause texts for eligibility + conflicts
        clause_texts = []
        for c in analysis.get("clauses", []):
            if isinstance(c, dict):
                clause_texts.append(c.get("text", c.get("title", "")))
            elif isinstance(c, str):
                clause_texts.append(c)

        # ── Stage 3: Eligibility ─────────────────────────────────────────────
        print(f"[{job_id}] Running eligibility check")
        try:
            eligibility = check_eligibility(text, clause_texts)
        except Exception as e:
            print(f"[{job_id}] Eligibility check failed (non-fatal): {e}")
            eligibility = {"error": str(e)}

        # ── Stage 4: Conflicts ───────────────────────────────────────────────
        print(f"[{job_id}] Running conflict detection")
        try:
            conflicts = find_conflicts(text, clause_texts)
        except Exception as e:
            print(f"[{job_id}] Conflict detection failed (non-fatal): {e}")
            conflicts = {"error": str(e)}

        # ── Stage 5: Save to DynamoDB ────────────────────────────────────────
        final_result = {
            **analysis,
            "eligibility": eligibility,
            "conflicts": conflicts,
            "word_count": word_count,
        }

        update_job(table, job_id, {
            "status": "COMPLETE",
            "stage": "done",
            "result": json.dumps(final_result),
        })
        print(f"[{job_id}] COMPLETE")

    except Exception as e:
        print(f"[{job_id}] FAILED: {e}")
        try:
            update_job(table, job_id, {
                "status": "FAILED",
                "stage": "failed",
                "error": str(e),
            })
        except Exception as inner:
            print(f"[{job_id}] Could not write FAILED status: {inner}")
